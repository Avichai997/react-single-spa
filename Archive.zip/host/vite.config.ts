import { defineConfig } from 'vite';
import tailwindcss from '@tailwindcss/vite';
import vitePluginSingleSpa from 'vite-plugin-single-spa';
import devImportMap from './src/importMap.dev.json';
import sharedImportMap from './src/importMap.shared.json';

// Collect all bare specifiers listed in the import maps so Vite leaves them
// for the browser to resolve via the native import map injected into the HTML.
const importMapExternals = [
  ...Object.keys(devImportMap.imports ?? {}),
  ...Object.keys(sharedImportMap.imports ?? {}),
];

export default defineConfig({
  plugins: [
    // Mark import-map modules as external so Vite doesn't try to resolve them
    {
      name: 'import-map-externals',
      enforce: 'pre',
      resolveId(source) {
        if (importMapExternals.includes(source)) {
          return { id: source, external: true };
        }
      },
    },
    tailwindcss(),
    vitePluginSingleSpa({
      type: 'root',
      imo: '4.2.0',
      imoUi: {
        variant: 'full',
        buttonPos: 'bottom-right',
      },
      importMaps: {
        type: 'overridable-importmap',
        dev: ['src/importMap.dev.json', 'src/importMap.shared.json'],
        build: ['src/importMap.json', 'src/importMap.shared.json'],
      },
    }),
  ],
  server: {
    port: 9000,
  },
});
