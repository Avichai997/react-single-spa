import { registerApplication, start } from 'single-spa';

registerApplication({
  name: '@chkp/sidebar',
  app: () => import('@chkp/sidebar'),
  activeWhen: ['/'],
});

registerApplication({
  name: '@chkp/page1',
  app: () => import('@chkp/page1'),
  activeWhen: ['/page1'],
});

registerApplication({
  name: '@chkp/page2',
  app: () => import('@chkp/page2'),
  activeWhen: ['/page2'],
});

start({ urlRerouteOnly: true });
