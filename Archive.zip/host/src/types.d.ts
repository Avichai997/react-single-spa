declare module '@chkp/sidebar';
declare module '@chkp/page1';
declare module '@chkp/page2';
